/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkginterface;

/**
 *
 * @author admin
 */
public interface warehouse {
    // Define interfaces for different menus
interface WarehouseMenu {
    void recordNewProduct();
    void manageSuppliers();
    void updateStock();
    void notifyStoremanForRestock();
    void manageOrders();
    void generatePickupSlip();
}

interface StoreManagerMenu {
    void manageEmployees();
    void manageCustomers();
    void assignPrivileges();
    void sendStockRequest();
    void receiveStock();
    void generateReports();
    void updateProductInformation();
}

interface SalesMenu {
    void viewQuotationRequests();
    void processPurchaseOrders();
    void processInStoreTransactions();
    void printPurchaseSlip();
    void viewTransactionHistory();
    void notifyManagerForRestock();
    void trackProductSales();
    void recordDamagedProducts();
    void issueDiscount();
    void generateSalesReports();
}

interface CustomerOnlineMenu {
    void viewProductRanges();
    void sendReviewsAndComments();
    void createPurchaseOrder();
    void cancelUpdatePurchaseOrder();
    void makePayments();
    void requestQuotations();
}

// Implement the classes for each menu
class WarehouseSystem implements WarehouseMenu {

        
        public void recordNewProduct() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void manageSuppliers() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        public void updateStock() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void notifyStoremanForRestock() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

       
        public void manageOrders() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void generatePickupSlip() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    // Implement methods for WarehouseMenu
}

class StoreManagerSystem implements StoreManagerMenu {

        
        public void manageEmployees() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

      
        public void manageCustomers() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void assignPrivileges() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void sendStockRequest() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

       
        public void receiveStock() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void generateReports() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void updateProductInformation() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    // Implement methods for StoreManagerMenu
}

class SalesSystem implements SalesMenu {

        
        public void viewQuotationRequests() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void processPurchaseOrders() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void processInStoreTransactions() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void printPurchaseSlip() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void viewTransactionHistory() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void notifyManagerForRestock() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

       
        public void trackProductSales() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void recordDamagedProducts() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void issueDiscount() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

       
        public void generateSalesReports() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    // Implement methods for SalesMenu
}

class CustomerOnlineSystem implements CustomerOnlineMenu {

       
        public void viewProductRanges() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void sendReviewsAndComments() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void createPurchaseOrder() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void cancelUpdatePurchaseOrder() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void makePayments() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        
        public void requestQuotations() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    
}


    }



