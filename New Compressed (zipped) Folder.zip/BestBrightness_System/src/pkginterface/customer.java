
package pkginterface;


    public class customer {
    // Attributes
    private String customerName;
    private int customerId;
    private String orderDate;
    private int orderId;
    private double discount;
    private int quantity;

    // Constructor
    public customer(String customerName, int customerId, String orderDate, int orderId, double discount, int quantity) {
        this.customerName = customerName;
        this.customerId = customerId;
        this.orderDate = orderDate;
        this.orderId = orderId;
        this.discount = discount;
        this.quantity = quantity;
    }

    // Getters and Setters
    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // Methods
    public void createPurchaseOrder() {
        // Implementation for creating a purchase order
    }

    public void cancelPurchaseOrder() {
        // Implementation for cancelling a purchase order
    }

    public void updatePurchaseOrder() {
        // Implementation for updating a purchase order
    }

    public void sendReview() {
        // Implementation for sending a product review
    }

    public void makePayment() {
        // Implementation for making a payment
    }

    public void viewProductRanges() {
        // Implementation for viewing product ranges
    }

    public void deleteProduct() {
        // Implementation for deleting a product
    }
}


