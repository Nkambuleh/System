/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkginterface;

/**
 *
 * @author admin
 */
//public interface StoreManager {
   public interface StoreManagerr{
    void acceptEmployee();
    void updateEmployee();
    void viewEmployees();
    void deleteEmployee();
    void acceptCustomer();
    void updateCustomer();
    void viewCustomers();
    void deleteCustomer();
    void createStockRequest();
    void cancelStockRequest();
    void updateStockRequest();
    void recordReceivedStock();
    void generateStockReceipt();
    
}
    

