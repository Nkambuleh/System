/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkginterface;

/**
 *
 * @author admin
 */
public class StoreManager {
    
    //public class StoreManager {
    // Attributes
    private String employeeName;
    private int employeeId;
    private String customerName;
    private int customerId;

    // Constructor
    public StoreManager(String employeeName, int employeeId, String customerName, int customerId) {
        this.employeeName = employeeName;
        this.employeeId = employeeId;
        this.customerName = customerName;
        this.customerId = customerId;
    }
     public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    // Methods
    public void acceptEmployee() {
        // Implementation for accepting and recording employees
    }

    public void updateEmployee() {
        // Implementation for updating employee information
    }

    public void viewEmployees() {
        // Implementation for viewing employees
    }

    public void deleteEmployee() {
        // Implementation for deleting an employee
    }

    public void acceptCustomer() {
        // Implementation for accepting and recording customers
    }

    public void updateCustomer() {
        // Implementation for updating customer information
    }

    public void viewCustomers() {
        // Implementation for viewing customers
    }

    public void deleteCustomer() {
        // Implementation for deleting a customer
    }

    public void assignPrivileges() {
        // Implementation for assigning privileges to users
    }

    public void createStockRequest() {
        // Implementation for creating and sending stock requests
    }

    public void cancelStockRequest() {
        // Implementation for cancelling stock requests
    }

    public void updateStockRequest() {
        // Implementation for updating stock requests
    }

    public void recordReceivedStock() {
        // Implementation for receiving and recording stock
    }

    public void generateStockReceipt() {
        // Implementation for generating a stock receipt
    }

    public void generateFinancialReport() {
        // Implementation for generating a financial report
    }
}


