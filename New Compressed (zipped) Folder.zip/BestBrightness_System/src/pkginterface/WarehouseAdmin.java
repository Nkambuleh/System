/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkginterface;

/**
 *
 * @author admin
 */
public interface WarehouseAdmin {
   
    void recordNewProduct();
    void updateStock();
    void requestNewStock();
    void receiveStock();
    void notifyManagerForRestock();
    void deleteProduct();
}

