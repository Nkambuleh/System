package pkginterface;


public class warehousemenu {
    
   // public class WarehouseMenu {
    // Attributes
    private String customerName;
    private String orderDate;
    private int customerId;
    private int orderId;
    private double discount;
    private int quantity;

    // Constructor
    public warehousemenu(String customerName, String orderDate, int customerId, int orderId, double discount, int quantity) {
        this.customerName = customerName;
        this.orderDate = orderDate;
        this.customerId = customerId;
        this.orderId = orderId;
        this.discount = discount;
        this.quantity = quantity;
    }
      public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }


    // Methods
    public void recordNewProduct() {
        // Implementation for recording a new product
    }

    public void updateStock() {
        // Implementation for updating stock information
    }

    public void requestNewStock() {
        // Implementation for requesting new stock
    }

    public void receiveStock() {
        // Implementation for receiving and recording stock
    }

    public void notifyManagerForRestock() {
        // Implementation for notifying manager for restock
    }

    public void generateDeliverySlip() {
        // Implementation for generating a delivery slip
    }

    public void generateStockReceipt() {
        // Implementation for generating a stock receipt
    }

    public void generateFinancialReport() {
        // Implementation for generating a financial report
    }

    public void deleteProduct() {
        // Implementation for deleting a product
    }
}

    


